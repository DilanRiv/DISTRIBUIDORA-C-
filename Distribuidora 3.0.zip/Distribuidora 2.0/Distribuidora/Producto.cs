﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distribuidora
{
   public class Producto
    {
        public int id;
        public string Nombre;
        public int Precio;
        public int Stock;
        public DateTime Vencimiento;

        public Producto(int i, string nom, int pre,int st,DateTime ven)
        {
            id = i;
            Nombre = nom;
            Precio = pre;
            Stock = st;
            Vencimiento = ven;

        }

    }
}
