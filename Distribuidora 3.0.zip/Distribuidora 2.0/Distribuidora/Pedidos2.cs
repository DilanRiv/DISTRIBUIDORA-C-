﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Distribuidora
{
    public partial class Pedidos2 : Form
    {
        DatPedido datpedido = new DatPedido();
        public DatPedido datpedi;
        public Pedidos2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NuevoPedido np = new NuevoPedido();
            np.dped = datpedido;
            np.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BuscarPedido bpe = new BuscarPedido();
            bpe.datped = datpedido;
            bpe.ShowDialog();
        }

        private void Pedidos2_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string html = "";
            html += "<html><head><title>Reporte de Pedidos</title>";
            html += "<style>";
            html += "body { font-family: Arial, sans-serif; margin: 20px; background-color: #e0e0e0; }";
            html += "h1 { color: #1a1a1a; text-align: center; background-color: #f5f5f5; border: 2px solid #1a1a1a; padding: 10px; font-size: 22px; letter-spacing: 2px; display: inline-block; width: 96%; }";
            html += ".header-container { text-align: center; margin-bottom: 20px; }";
            html += "table { width: 85%; margin: 20px auto; border-collapse: collapse; background-color: #f5f5f5; box-shadow: 4px 4px 8px rgba(0,0,0,0.3); }";
            html += "th { background-color: #3a3a3a; color: white; padding: 12px; text-align: center; font-weight: bold; letter-spacing: 1px; }";
            html += "td { padding: 10px; text-align: center; border-bottom: 1px solid #bbb; color: #1a1a1a; }";
            html += "tr:hover { background-color: #d5d5d5; }";
            html += "table, th, td { border: 1px solid #aaa; }";
            html += "</style>";
            html += "</head><body>";

            html += "<div class='header-container'><h1>📋 Reporte de Pedidos</h1></div>";
            html += "<table>";
            html += "<tr><th>ID Pedidos</th><th>Productos</th><th>Cantidad</th><th>Fecha</th><th>Tienda</th></tr>";

            foreach (Pedido aux in datpedido.pedidos)
            {
                html += "<tr>";
                html += "<td>" + aux.id + "</td>";
                html += "<td>" + datpedido.traerProductoPorNombre(aux.productos) + "</td>";
                html += "<td>" + datpedido.traerProductoPorCantidad(aux.cantidad) + "</td>";
                html += "<td>" + datpedido.traerProductoPorFecha(aux.fecha) + "</td>";
                html += "<td>" + datpedido.traerProductoPorTienda(aux.tienda) + "</td>";

                html += "</tr>";
            }

            html += "</table></body></html>";


            using (StreamWriter sw = new StreamWriter("reportePedido.html"))
            {
                sw.WriteLine(html);
            }
            Process.Start("reportePedido.html");
        }
    }
}
