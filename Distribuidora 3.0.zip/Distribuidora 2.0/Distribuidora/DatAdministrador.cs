﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Distribuidora
{
    public class DatAdministrador
    {
        public List<Administrador> administradores = new List<Administrador>();

        public DatAdministrador()
        {
            leer();
        }

        private int nextId()
        {
            int mayor = 0;
            foreach (Administrador aux in administradores)
            {
                if (aux.id > mayor)
                {
                    mayor = aux.id;
                }
            }
            mayor = mayor + 1;
            return mayor;
        }

        public void agregar(Administrador parametro)
        {
            try
            {
                parametro.id = nextId();
                administradores.Add(parametro);
                guardar();
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al agregar administrador: " + exe.Message);
            }
        }

        public int verificar(string plo, string ppas)
        {
            try
            {
                foreach (Administrador aux in administradores)
                {
                    if (aux.login == plo && aux.password == ppas)
                    {
                        return aux.id;
                    }
                }
                return -1;
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al verificar administrador: " + exe.Message);
                return -1;
            }
        }

        private void guardar()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("administrador.txt"))
                {
                    foreach (Administrador aux in administradores)
                    {
                        sw.WriteLine(aux.id + "#" + aux.login + "#" +
                            aux.password + "#" + aux.nombre + "#" +
                            aux.apellido + "#" + aux.rol);
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al guardar el archivo: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al guardar: " + exe.Message);
            }
        }

        private void leer()
        {
            try
            {
                administradores.Clear();

                if (!File.Exists("administrador.txt"))
                {
                    File.Create("administrador.txt").Close();
                    return;
                }

                using (StreamReader sr = new StreamReader("administrador.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] part = linea.Split('#');
                        administradores.Add(new Administrador(int.Parse(part[0]),
                            part[1], part[2], part[3], part[4], part[5]));
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al leer el archivo: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Archivo dañado o con formato incorrecto: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al leer: " + exe.Message);
            }
        }
    }
}