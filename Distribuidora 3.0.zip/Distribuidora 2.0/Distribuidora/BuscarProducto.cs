﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Distribuidora
{
    public partial class BuscarProducto : Form
    {
        DatProducto datproducto = new DatProducto();
        public DatProducto datpro;
        public int idseleccionado = -1;

        public BuscarProducto()
        {
            InitializeComponent();
        }

        public void mostrar(string filtro)
        {
            try
            {
                dataGridView1.Rows.Clear();
                foreach (Producto aux in datpro.productos)
                {
                    if (aux.Nombre.ToUpper().Contains(filtro.ToUpper()) || filtro == "")
                    {
                        int rowIndex = dataGridView1.Rows.Add();
                        dataGridView1.Rows[rowIndex].Cells[0].Value = aux.id;
                        dataGridView1.Rows[rowIndex].Cells[1].Value = aux.Nombre;
                        dataGridView1.Rows[rowIndex].Cells[2].Value = aux.Precio;
                        dataGridView1.Rows[rowIndex].Cells[3].Value = aux.Stock;
                        dataGridView1.Rows[rowIndex].Cells[4].Value = aux.Vencimiento;
                    }
                }
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar productos: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            mostrar(textBox1.Text);
        }

        private void BuscarProducto_Load(object sender, EventArgs e)
        {
            try
            {
                mostrar("");
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al cargar el formulario: " + exe.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FrmNuevoProducto fnp = new FrmNuevoProducto();
                fnp.dpro = datpro;
                fnp.ShowDialog();
                mostrar("");
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al abrir formulario: " + exe.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    mostrar("");
                }
                catch (Exception exe)
                {
                    MessageBox.Show("Error inesperado: " + exe.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}