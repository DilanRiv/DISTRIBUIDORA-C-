﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Distribuidora
{
    public class DatAlmacen
    {
        public List<Almacen> almacenes = new List<Almacen>();

        public DatAlmacen()
        {
            leer();
        }

        private int nextId()
        {
            int mayor = 0;
            foreach (Almacen aux in almacenes)
            {
                if (aux.id > mayor)
                {
                    mayor = aux.id;
                }
            }
            mayor = mayor + 1;
            return mayor;
        }

        public void agregar(Almacen parametro)
        {
            try
            {
                parametro.id = nextId();
                almacenes.Add(parametro);
                guardar();
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al agregar almacen: " + exe.Message);
            }
        }

        public string traerNombrePorID(int pid)
        {
            try
            {
                foreach (Almacen aux in almacenes)
                {
                    if (aux.id == pid)
                    {
                        return aux.nombre;
                    }
                }
                return "no encontrado";
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar almacen: " + exe.Message);
                return "no encontrado";
            }
        }

        private void guardar()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("almacen.txt"))
                {
                    foreach (Almacen aux in almacenes)
                    {
                        sw.WriteLine(aux.id + "#" + aux.nombre);
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al guardar el archivo: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al guardar: " + exe.Message);
            }
        }

        private void leer()
        {
            try
            {
                almacenes.Clear();

                if (!File.Exists("almacen.txt"))
                {
                    File.Create("almacen.txt").Close();
                    return;
                }

                using (StreamReader sr = new StreamReader("almacen.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] part = linea.Split('#');
                        almacenes.Add(new Almacen(int.Parse(part[0]), part[1]));
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al leer el archivo: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Archivo dañado o con formato incorrecto: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al leer: " + exe.Message);
            }
        }
    }
}