﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class FrmNuevaTienda : Form
    {
        public DatTienda dti;

        public FrmNuevaTienda()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text) ||
                    string.IsNullOrEmpty(textBox2.Text) ||
                    string.IsNullOrEmpty(textBox3.Text))
                    throw new NullReferenceException("Todos los campos son obligatorios.");

                string nom = textBox1.Text;
                string dir = textBox2.Text;
                int NT = int.Parse(textBox3.Text);

                dti.agregar(new Tienda(-1, nom, dir, NT));
                Close();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Campo vacío: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("El número de teléfono debe ser un número: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}