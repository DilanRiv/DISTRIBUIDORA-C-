﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distribuidora
{
    public class Facturas
    {
        public int id;
        public string Nombre;
        public DateTime Fecha;
        public int Total;
        public int Pedido;
        public string Tienda;

        public Facturas(int i, string nom, DateTime fe, int tot, int ped, string tie)
        {
            id = i;
            Nombre = nom;
            Fecha = fe;
            Total = tot;
            Pedido = ped;
            Tienda = tie;

        }
    }
}
