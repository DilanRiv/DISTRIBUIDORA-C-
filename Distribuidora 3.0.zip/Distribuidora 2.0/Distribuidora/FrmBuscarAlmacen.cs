﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class FrmBuscarAlmacen : Form
    {
        public DatAlmacen datalm;
        public int idseleccionado = -1;

        public FrmBuscarAlmacen()
        {
            InitializeComponent();
            try
            {
                datalm = new DatAlmacen();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar datos: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        public void mostrar(string filtro)
        {
            try
            {
                dataGridView1.Rows.Clear();
                foreach (Almacen aux in datalm.almacenes)
                {
                    if (aux.nombre.ToUpper().Contains(filtro.ToUpper()) || filtro == "")
                    {
                        int rowIndex = dataGridView1.Rows.Add();
                        dataGridView1.Rows[rowIndex].Cells[0].Value = aux.id;
                        dataGridView1.Rows[rowIndex].Cells[1].Value = aux.nombre;
                    }
                }
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar almacenes: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            mostrar(textBox1.Text);
        }

        private void FrmBuscarAlmacen_Load(object sender, EventArgs e)
        {
            try
            {
                mostrar("");
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al cargar el formulario: " + exe.Message);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}