﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distribuidora
{
   public class Administrador : Usuario
    {
        public Administrador(int i, string lo, string pa, string nom, string ape, string ro) : base(i, lo, pa, nom, ape, ro)
        {
            id = i;
            login = lo;
            password = pa;
            nombre = nom;
            apellido = ape;
            rol = ro;
        }
    }
}
