﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class Form1 : Form
    {
        DatProducto datproducto = new DatProducto();
        DatPedido datpedido = new DatPedido();
        DatTienda dattienda = new DatTienda();
        DatTransporte dattransporte = new DatTransporte();
        DatAdministrador datadministrador = new DatAdministrador();
        DatFactura datfactura = new DatFactura();
        DatAlmacen datalmacen = new DatAlmacen();

        public Form1()
        {
            InitializeComponent();
        }

        private void transporteToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void nuevoProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNuevoProducto fnp = new FrmNuevoProducto();
            fnp.dpro = datproducto;
            fnp.ShowDialog();
        }

        private void buscarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BuscarProducto bpr = new BuscarProducto();
            bpr.datpro = datproducto;
            bpr.ShowDialog();
        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void nuevoPedidoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NuevoPedido np = new NuevoPedido();
             np.dped = datpedido;
             np.ShowDialog();
        }

        private void buscarPedidoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BuscarPedido bpe = new BuscarPedido();
            bpe.datped = datpedido;
            bpe.ShowDialog();
        }

        private void registrarTiendaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNuevaTienda fnt = new FrmNuevaTienda();
            fnt.dti = dattienda;
            fnt.ShowDialog();
        }

        private void buscarTiendasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmBuscarTienda fbt = new FrmBuscarTienda();
            fbt.dattie = dattienda;
            fbt.ShowDialog();
        }

        private void registrarTransporteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNuevoTransporte ftr = new FrmNuevoTransporte();
            ftr.dtra = dattransporte;
            ftr.ShowDialog();
        }

        private void buscarTransporteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmBuscarTransporte fbtra = new FrmBuscarTransporte();
            fbtra.dattran = dattransporte;
            fbtra.ShowDialog();
        }

        private void nuevoADMINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNuevoAdministrador fna = new FrmNuevoAdministrador();
            fna.datadministrador = datadministrador;
            fna.ShowDialog();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void facturasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Factura fac = new Factura();
            fac.fact = datfactura;
            fac.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Login.rolestatico != "Administrador")
            {
                button5.Enabled = false;
            }
            this.Text = Login.rolestatico + " ID:" + Login.idestatico;
        }

        private void tiendasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void registrarAlmacenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmNuevoAlmacen fnaalm = new FrmNuevoAlmacen();
            fnaalm.dal = datalmacen;
            fnaalm.ShowDialog();
        }

        private void buscarAlmacenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmBuscarAlmacen fnal = new FrmBuscarAlmacen();
            fnal.datalm = datalmacen;
            fnal.ShowDialog();
        }

        private void almacenToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Almacen2 alma = new Almacen2();
            alma.datalma = datalmacen;
            alma.ShowDialog();
        }

        private void listaDeProductosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void pedidosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Pedidos2 pedi = new Pedidos2();
            pedi.datpedi = datpedido;
            pedi.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tiendas2 tiend = new Tiendas2();
            tiend.dattien = dattienda;
            tiend.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Transporte2 trans = new Transporte2();
            trans.dattrans = dattransporte;
            trans.ShowDialog();
        }

        private void aDMINToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Admin2 admin = new Admin2();
            admin.datadmins = datadministrador;
            admin.ShowDialog();
        }
    }
}
