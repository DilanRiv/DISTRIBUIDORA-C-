﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Distribuidora
{
    public class DatPedido
    {
        public List<Pedido> pedidos = new List<Pedido>();

        public DatPedido()
        {
            leer();
        }

        private int nextId()
        {
            int mayor = 0;
            foreach (Pedido aux in pedidos)
            {
                if (aux.id > mayor)
                {
                    mayor = aux.id;
                }
            }
            mayor = mayor + 1;
            return mayor;
        }

        public void agregar(Pedido parametro)
        {
            try
            {
                parametro.id = nextId();
                pedidos.Add(parametro);
                guardar();
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al agregar pedido: " + exe.Message);
            }
        }

        public string traerProductoPorNombre(string nombre)
        {
            try
            {
                foreach (Pedido aux in pedidos)
                {
                    if (aux.productos == nombre)
                    {
                        return aux.productos;
                    }
                }
                return "no se ha encontrado";
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar por nombre: " + exe.Message);
                return "no se ha encontrado";
            }
        }

        public int traerProductoPorCantidad(int cantidad)
        {
            try
            {
                foreach (Pedido aux in pedidos)
                {
                    if (aux.cantidad == cantidad)
                    {
                        return aux.cantidad;
                    }
                }
                return -1;
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar por cantidad: " + exe.Message);
                return -1;
            }
        }

        public string traerProductoPorFecha(DateTime fecha)
        {
            try
            {
                foreach (Pedido aux in pedidos)
                {
                    if (aux.fecha == fecha)
                    {
                        return aux.fecha.ToString("dd/MM/yyyy");
                    }
                }
                return "no se ha encontrado";
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar por fecha: " + exe.Message);
                return "no se ha encontrado";
            }
        }

        public string traerProductoPorTienda(string tienda)
        {
            try
            {
                foreach (Pedido aux in pedidos)
                {
                    if (aux.tienda == tienda)
                    {
                        return aux.tienda;
                    }
                }
                return "no se ha encontrado";
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar por tienda: " + exe.Message);
                return "no se ha encontrado";
            }
        }

        private void guardar()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("pedido.txt"))
                {
                    foreach (Pedido aux in pedidos)
                    {
                        sw.WriteLine(aux.id + "#" + aux.fecha + "#" + aux.productos + "#" +
                            aux.cantidad + "#" + aux.tienda);
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al guardar el archivo: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al guardar: " + exe.Message);
            }
        }

        private void leer()
        {
            try
            {
                pedidos.Clear();

                if (!File.Exists("pedido.txt"))
                {
                    File.Create("pedido.txt").Close();
                    return;
                }

                using (StreamReader sr = new StreamReader("pedido.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] part = linea.Split('#');
                        pedidos.Add(new Pedido(
                            int.Parse(part[0]),
                            DateTime.Parse(part[1]),
                            part[2],
                            int.Parse(part[3]),
                            part[4]
                        ));
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al leer el archivo: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Archivo dañado o con formato incorrecto: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al leer: " + exe.Message);
            }
        }
    }
}