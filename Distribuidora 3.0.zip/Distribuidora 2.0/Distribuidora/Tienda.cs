﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distribuidora
{
   public class Tienda
    {
        public int id;
        public string nombre;
        public string direccion;
        public int NIT;
        

        public Tienda(int i, string nom, string dir, int NT)
        {
            id = i;
            nombre = nom;
            direccion = dir;
            NIT = NT;
            

        }
    }
}
