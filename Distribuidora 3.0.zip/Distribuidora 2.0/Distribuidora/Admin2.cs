﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class Admin2 : Form
    {
        DatAdministrador datadministrador = new DatAdministrador();
        DatFactura datfactura = new DatFactura();
        DatUsuario datusuario = new DatUsuario();
        public DatAdministrador datadmins;
        public Admin2()
        {
            InitializeComponent();
        }

        private void Admin2_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmNuevoAdministrador fna = new FrmNuevoAdministrador();
            fna.datadministrador = datadministrador;
            fna.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Factura fac = new Factura();
            fac.fact = datfactura;
            fac.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmNuevoUsuario fnusu = new FrmNuevoUsuario();
            fnusu.datusuar = datusuario;
            fnusu.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmBuscarUsuario fnrmbus = new FrmBuscarUsuario();
            fnrmbus.datus = datusuario;
            fnrmbus.datadm = datadministrador;
            fnrmbus.ShowDialog();
        }
    }
}
