﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distribuidora
{
   public class Usuario
    {
        public int id;
        public string login;
        public string password;
        public string nombre;
        public string apellido;
        public string rol;
        public Usuario(int i, string lo, string pa, string nom, string ape, string ro)
        {
           
            
                id = i;
                login = lo;
                password = pa;
                nombre = nom;
                apellido = ape;
                rol = ro;
            


        }

        }
}
