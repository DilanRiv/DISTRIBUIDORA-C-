﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class FrmNuevoAdministrador : Form
    {
        public DatAdministrador datadministrador = new DatAdministrador();
        public FrmNuevoAdministrador()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string lo = textBox1.Text;
            string pa = textBox2.Text;
            string no = textBox3.Text;
            string ape = textBox4.Text;
            string ro = "Administrador";
            
            datadministrador.agregar(new Administrador(-1, lo, pa, no, ape, ro));
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
