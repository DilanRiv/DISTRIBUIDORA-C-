﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distribuidora
{
   public class Almacen
    {
        public int id;
        public string nombre;
        


        public Almacen(int i, string nom)
        {
            id = i;
            nombre = nom;
            


        }
    }
}
