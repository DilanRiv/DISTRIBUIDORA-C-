﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Distribuidora
{
    public class DatUsuario
    {
        public List<Usuario> usuarios = new List<Usuario>();

        public DatUsuario()
        {
            leer();
        }

        public int nextId()
        {
            int mayor = 0;
            foreach (Usuario aux in usuarios)
            {
                if (aux.id > mayor)
                {
                    mayor = aux.id;
                }
            }
            mayor = mayor + 1;
            return mayor;
        }

        public void agregar(Usuario parametro)
        {
            try
            {
                parametro.id = nextId();
                usuarios.Add(parametro);
                guardar();
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al agregar usuario: " + exe.Message);
            }
        }

        public int verificar(string plo, string ppas)
        {
            try
            {
                foreach (Usuario aux in usuarios)
                {
                    if (aux.login == plo && aux.password == ppas)
                    {
                        return aux.id;
                    }
                }
                return -1;
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al verificar usuario: " + exe.Message);
                return -1;
            }
        }

        public string traerNomprePorId(int pid)
        {
            try
            {
                foreach (Usuario aux in usuarios)
                {
                    if (aux.id == pid)
                    {
                        return aux.apellido + ", " + aux.nombre;
                    }
                }
                return "no se ha encontrado";
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar usuario: " + exe.Message);
                return "no se ha encontrado";
            }
        }

        private void guardar()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("usuario.txt"))
                {
                    foreach (Usuario aux in usuarios)
                    {
                        sw.WriteLine(aux.id + "#" + aux.login + "#" +
                            aux.password + "#" + aux.nombre + "#" +
                            aux.apellido + "#" + aux.rol);
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al guardar el archivo: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al guardar: " + exe.Message);
            }
        }

        private void leer()
        {
            try
            {
                usuarios.Clear();

                if (!File.Exists("usuario.txt"))
                {
                    File.Create("usuario.txt").Close();
                    return;
                }

                using (StreamReader sr = new StreamReader("usuario.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] part = linea.Split('#');
                        usuarios.Add(new Usuario(
                            int.Parse(part[0]),
                            part[1],
                            part[2],
                            part[3],
                            part[4],
                            part[5]
                        ));
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al leer el archivo: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Archivo dañado o con formato incorrecto: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al leer: " + exe.Message);
            }
        }
    }
}