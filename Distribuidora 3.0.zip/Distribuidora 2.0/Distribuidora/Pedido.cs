﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distribuidora
{
  public  class Pedido
    {
        public int id;
        public DateTime fecha;
        public string productos;
        public int cantidad;
        public string tienda;


        public Pedido(int i, DateTime fec,string prod , int can, string tie)
        {
            id = i;
            fecha = fec;
            productos= prod;
            cantidad = can;
            tienda = tie;

    }
    }
}
