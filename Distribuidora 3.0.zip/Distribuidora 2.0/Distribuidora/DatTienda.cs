﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Distribuidora
{
    public class DatTienda
    {
        public List<Tienda> tiendas = new List<Tienda>();

        public DatTienda()
        {
            leer();
        }

        private int nextId()
        {
            int mayor = 0;
            foreach (Tienda aux in tiendas)
            {
                if (aux.id > mayor)
                {
                    mayor = aux.id;
                }
            }
            mayor = mayor + 1;
            return mayor;
        }

        public void agregar(Tienda parametro)
        {
            try
            {
                parametro.id = nextId();
                tiendas.Add(parametro);
                guardar();
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al agregar tienda: " + exe.Message);
            }
        }

        public string traerNombrePorID(int pid)
        {
            try
            {
                foreach (Tienda aux in tiendas)
                {
                    if (aux.id == pid)
                    {
                        return aux.nombre;
                    }
                }
                return "no encontrado";
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar tienda: " + exe.Message);
                return "no encontrado";
            }
        }

        private void guardar()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("tienda.txt"))
                {
                    foreach (Tienda aux in tiendas)
                    {
                        sw.WriteLine(aux.id + "#" + aux.nombre + "#" +
                            aux.direccion + "#" + aux.NIT);
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al guardar el archivo: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al guardar: " + exe.Message);
            }
        }

        private void leer()
        {
            try
            {
                tiendas.Clear();

                if (!File.Exists("tienda.txt"))
                {
                    File.Create("tienda.txt").Close();
                    return;
                }

                using (StreamReader sr = new StreamReader("tienda.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] part = linea.Split('#');
                        tiendas.Add(new Tienda(
                            int.Parse(part[0]),
                            part[1],
                            part[2],
                            int.Parse(part[3])
                        ));
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al leer el archivo: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Archivo dañado o con formato incorrecto: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al leer: " + exe.Message);
            }
        }
    }
}