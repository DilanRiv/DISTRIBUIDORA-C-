﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Distribuidora
{
    public class DatProducto
    {
        public List<Producto> productos = new List<Producto>();

        public DatProducto()
        {
            leer();
        }

        private int nextId()
        {
            int mayor = 0;
            foreach (Producto aux in productos)
            {
                if (aux.id > mayor)
                {
                    mayor = aux.id;
                }
            }
            mayor = mayor + 1;
            return mayor;
        }

        public void agregar(Producto parametro)
        {
            try
            {
                parametro.id = nextId();
                productos.Add(parametro);
                guardar();
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al agregar producto: " + exe.Message);
            }
        }

        public string traerNombrePorID(int pid)
        {
            try
            {
                foreach (Producto aux in productos)
                {
                    if (aux.id == pid)
                    {
                        return aux.Nombre;
                    }
                }
                return "no encontrado";
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar producto: " + exe.Message);
                return "no encontrado";
            }
        }

        private void guardar()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("producto.txt"))
                {
                    foreach (Producto aux in productos)
                    {
                        sw.WriteLine(aux.id + "#" + aux.Nombre + "#" + aux.Precio + "#" +
                            aux.Stock + "#" + aux.Vencimiento);
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al guardar el archivo: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al guardar: " + exe.Message);
            }
        }

        private void leer()
        {
            try
            {
                productos.Clear();

                if (!File.Exists("producto.txt"))
                {
                    File.Create("producto.txt").Close();
                    return;
                }

                using (StreamReader sr = new StreamReader("producto.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] part = linea.Split('#');
                        productos.Add(new Producto(
                            int.Parse(part[0]),
                            part[1],
                            int.Parse(part[2]),
                            int.Parse(part[3]),
                            DateTime.Parse(part[4])));
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al leer el archivo: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Archivo dañado o con formato incorrecto: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al leer: " + exe.Message);
            }
        }
    }
}
