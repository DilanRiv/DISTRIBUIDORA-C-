﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class FrmNuevoAlmacen : Form
    {
        public DatAlmacen dal;

        public FrmNuevoAlmacen()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text))
                    throw new NullReferenceException("El nombre es obligatorio.");

                string nom = textBox1.Text;
                dal.agregar(new Almacen(-1, nom));
                Close();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Campo vacío: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}