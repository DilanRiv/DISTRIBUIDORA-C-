﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class Login : Form
    {
        DatAdministrador da;
        DatUsuario du;

        public Login()
        {
            InitializeComponent();
            try
            {
                da = new DatAdministrador();
                du = new DatUsuario();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar datos: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        public static string rolestatico = "";
        public static int idestatico = -1;

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text) ||
                    string.IsNullOrEmpty(textBox2.Text))
                    throw new NullReferenceException("Usuario y contraseña son obligatorios.");

                string log = textBox1.Text;
                string pas = textBox2.Text;

                int id = da.verificar(log, pas);
                if (id != -1)
                {
                    rolestatico = "Administrador";
                    idestatico = id;
                    Form1 f1 = new Form1();
                    f1.Show();
                    Hide();
                    return;
                }

                id = du.verificar(log, pas);
                if (id != -1)
                {
                    rolestatico = "Usuario";
                    idestatico = id;
                    Form1 f1 = new Form1();
                    f1.Show();
                    Hide();
                    return;
                }

                MessageBox.Show("USUARIO NO ENCONTRADO");
                textBox1.Clear();
                textBox2.Clear();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Campo vacío: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }
    }
}