﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class Tiendas2 : Form
    {
        DatTienda dattienda = new DatTienda();
        public DatTienda dattien;
        public Tiendas2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmNuevaTienda fnt = new FrmNuevaTienda();
            fnt.dti = dattienda;
            fnt.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmBuscarTienda fbt = new FrmBuscarTienda();
            fbt.dattie = dattienda;
            fbt.ShowDialog();
        }
    }
}
