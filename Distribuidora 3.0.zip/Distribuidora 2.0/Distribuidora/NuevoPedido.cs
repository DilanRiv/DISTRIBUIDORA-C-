﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class NuevoPedido : Form
    {
        public DatPedido dped;

        public NuevoPedido()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text) ||
                    string.IsNullOrEmpty(textBox2.Text) ||
                    string.IsNullOrEmpty(textBox3.Text))
                    throw new NullReferenceException("Todos los campos son obligatorios.");

                DateTime fec = dateTimePicker1.Value;
                string prod = textBox1.Text;
                int can = int.Parse(textBox2.Text);
                string tie = textBox3.Text;

                dped.agregar(new Pedido(-1, fec, prod, can, tie));
                Close();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Campo vacío: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("La cantidad debe ser un número: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
