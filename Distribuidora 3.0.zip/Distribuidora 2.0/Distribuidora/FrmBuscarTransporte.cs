﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class FrmBuscarTransporte : Form
    {
        public DatTransporte dattran;
        public int idseleccionado = -1;

        public FrmBuscarTransporte()
        {
            InitializeComponent();
            try
            {
                dattran = new DatTransporte();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar datos: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        public void mostrar(string filtro)
        {
            try
            {
                dataGridView1.Rows.Clear();
                foreach (Transporte aux in dattran.transportes)
                {
                    if (aux.id.ToString().ToUpper().Contains(filtro.ToUpper()) || filtro == "")
                    {
                        int rowIndex = dataGridView1.Rows.Add();
                        dataGridView1.Rows[rowIndex].Cells[0].Value = aux.id;
                        dataGridView1.Rows[rowIndex].Cells[1].Value = aux.Tipo;
                        dataGridView1.Rows[rowIndex].Cells[2].Value = aux.Estado;
                        dataGridView1.Rows[rowIndex].Cells[3].Value = aux.Placa;
                    }
                }
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar transportes: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            mostrar(textBox1.Text);
        }

        private void FrmBuscarTransporte_Load(object sender, EventArgs e)
        {
            try
            {
                mostrar("");
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al cargar el formulario: " + exe.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}