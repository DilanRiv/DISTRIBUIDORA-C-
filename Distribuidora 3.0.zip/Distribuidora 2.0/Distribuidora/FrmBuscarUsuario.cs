﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class FrmBuscarUsuario : Form
    {
        public DatUsuario datus;
        public DatAdministrador datadm;
        public int idseleccionado = -1;

        public FrmBuscarUsuario()
        {
            InitializeComponent();
            try
            {
                datus = new DatUsuario();
                datadm = new DatAdministrador();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar datos: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        public void mostrar(string filtro)
        {
            try
            {
                dataGridView1.Rows.Clear();

               
                foreach (Administrador aux in datadm.administradores)
                {
                    if (aux.nombre.ToUpper().Contains(filtro.ToUpper()) || filtro == "")
                    {
                        int rowIndex = dataGridView1.Rows.Add();
                        dataGridView1.Rows[rowIndex].Cells[0].Value = aux.id;
                        dataGridView1.Rows[rowIndex].Cells[1].Value = aux.nombre;
                        dataGridView1.Rows[rowIndex].Cells[2].Value = aux.apellido;
                        dataGridView1.Rows[rowIndex].Cells[3].Value = aux.login;
                        dataGridView1.Rows[rowIndex].Cells[4].Value = aux.rol;
                    }
                }

                
                foreach (Usuario aux in datus.usuarios)
                {
                    if (aux.nombre.ToUpper().Contains(filtro.ToUpper()) || filtro == "")
                    {
                        int rowIndex = dataGridView1.Rows.Add();
                        dataGridView1.Rows[rowIndex].Cells[0].Value = aux.id;
                        dataGridView1.Rows[rowIndex].Cells[1].Value = aux.nombre;
                        dataGridView1.Rows[rowIndex].Cells[2].Value = aux.apellido;
                        dataGridView1.Rows[rowIndex].Cells[3].Value = aux.login;
                        dataGridView1.Rows[rowIndex].Cells[4].Value = aux.rol;
                    }
                }
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar usuarios: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

  

       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            mostrar(textBox1.Text);
        }

        private void FrmBuscarUsuario_Load(object sender, EventArgs e)
        {
            try
            {
                mostrar("");
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al cargar el formulario: " + exe.Message);
            }
        }
    }
}