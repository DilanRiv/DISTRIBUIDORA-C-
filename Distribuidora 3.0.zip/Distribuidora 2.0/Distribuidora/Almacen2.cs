﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class Almacen2 : Form
    {
        DatProducto datproducto = new DatProducto();
        DatAlmacen datalmacen = new DatAlmacen();
        public DatAlmacen datalma;
        public Almacen2()
        {
            InitializeComponent();
        }

        private void Almacen2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmNuevoAlmacen fnaalm = new FrmNuevoAlmacen();
            fnaalm.dal = datalmacen;
            fnaalm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmBuscarAlmacen fnal = new FrmBuscarAlmacen();
            fnal.datalm = datalmacen;
            fnal.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BuscarProducto bpr = new BuscarProducto();
            bpr.datpro = datproducto;
            bpr.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmNuevoProducto fnp = new FrmNuevoProducto();
            fnp.dpro = datproducto;
            fnp.ShowDialog();
        }
    }
}
