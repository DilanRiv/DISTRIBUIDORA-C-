﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class BuscarPedido : Form
    {
        public DatPedido datped;
        public int idseleccionado = -1;

        public BuscarPedido()
        {
            InitializeComponent();
        }

        public void mostrar(string filtro)
        {
            try
            {
                dataGridView1.Rows.Clear();
                foreach (Pedido aux in datped.pedidos)
                {
                    if (aux.id.ToString().ToUpper().Contains(filtro.ToUpper()) || filtro == "")
                    {
                        int rowIndex = dataGridView1.Rows.Add();
                        dataGridView1.Rows[rowIndex].Cells[0].Value = aux.id;
                        dataGridView1.Rows[rowIndex].Cells[1].Value = aux.fecha;
                        dataGridView1.Rows[rowIndex].Cells[2].Value = aux.productos;
                        dataGridView1.Rows[rowIndex].Cells[3].Value = aux.cantidad;
                        dataGridView1.Rows[rowIndex].Cells[4].Value = aux.tienda;
                    }
                }
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar pedidos: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            mostrar(textBox1.Text);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void BuscarPedido_Load(object sender, EventArgs e)
        {
            try
            {
                mostrar("");
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al cargar el formulario: " + exe.Message);
            }
        }
    }
}