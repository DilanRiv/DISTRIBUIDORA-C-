﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class Factura : Form
    {
        public DatFactura fact = new DatFactura();
        public Factura()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nom = textBox4.Text;
            DateTime fec = dateTimePicker1.Value;
            int tot = int.Parse(textBox1.Text);
            int ped = int.Parse(textBox2.Text);
            string tie = textBox3.Text;

            fact.agregar(new Facturas(-1, nom, fec, tot, ped ,tie));
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
