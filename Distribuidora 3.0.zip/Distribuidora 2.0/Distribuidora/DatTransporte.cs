﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Distribuidora
{
    public class DatTransporte
    {
        public List<Transporte> transportes = new List<Transporte>();

        public DatTransporte()
        {
            leer();
        }

        private int nextId()
        {
            int mayor = 0;
            foreach (Transporte aux in transportes)
            {
                if (aux.id > mayor)
                {
                    mayor = aux.id;
                }
            }
            mayor = mayor + 1;
            return mayor;
        }

        public void agregar(Transporte parametro)
        {
            try
            {
                parametro.id = nextId();
                transportes.Add(parametro);
                guardar();
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al agregar transporte: " + exe.Message);
            }
        }

        private void guardar()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("transporte.txt"))
                {
                    foreach (Transporte aux in transportes)
                    {
                        sw.WriteLine(aux.id + "#" + aux.Tipo + "#" +
                            aux.Estado + "#" + aux.Placa);
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al guardar el archivo: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al guardar: " + exe.Message);
            }
        }

        private void leer()
        {
            try
            {
                transportes.Clear();

                if (!File.Exists("transporte.txt"))
                {
                    File.Create("transporte.txt").Close();
                    return;
                }

                using (StreamReader sr = new StreamReader("transporte.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] part = linea.Split('#');
                        transportes.Add(new Transporte(
                            int.Parse(part[0]),
                            part[1],
                            part[2],
                            part[3]
                        ));
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al leer el archivo: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Archivo dañado o con formato incorrecto: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al leer: " + exe.Message);
            }
        }
    }
}