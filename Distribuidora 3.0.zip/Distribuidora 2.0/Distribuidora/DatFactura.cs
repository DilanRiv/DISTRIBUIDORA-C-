﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Distribuidora
{
    public class DatFactura
    {
        public List<Facturas> facturase = new List<Facturas>();

        public DatFactura()
        {
            leer();
        }

        private int nextId()
        {
            int mayor = 0;
            foreach (Facturas aux in facturase)
            {
                if (aux.id > mayor)
                {
                    mayor = aux.id;
                }
            }
            mayor = mayor + 1;
            return mayor;
        }

        public void agregar(Facturas parametro)
        {
            try
            {
                parametro.id = nextId();
                facturase.Add(parametro);
                guardar();
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al agregar factura: " + exe.Message);
            }
        }

        public string traerNombrePorID(int pid)
        {
            try
            {
                foreach (Facturas aux in facturase)
                {
                    if (aux.id == pid)
                    {
                        return aux.Nombre;
                    }
                }
                return "no encontrado";
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al buscar factura: " + exe.Message);
                return "no encontrado";
            }
        }

        private void guardar()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("factura.txt"))
                {
                    foreach (Facturas aux in facturase)
                    {
                        sw.WriteLine(aux.id + "#" + aux.Nombre + "#" + aux.Fecha + "#" +
                            aux.Total + "#" + aux.Pedido + "#" + aux.Tienda);
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al guardar el archivo: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al guardar: " + exe.Message);
            }
        }

        private void leer()
        {
            try
            {
                facturase.Clear();

                if (!File.Exists("factura.txt"))
                {
                    File.Create("factura.txt").Close();
                    return;
                }

                using (StreamReader sr = new StreamReader("factura.txt"))
                {
                    string linea;
                    while ((linea = sr.ReadLine()) != null)
                    {
                        string[] part = linea.Split('#');
                        facturase.Add(new Facturas(
                            int.Parse(part[0]),
                            part[1],
                            DateTime.Parse(part[2]),
                            int.Parse(part[3]),
                            int.Parse(part[4]),
                            part[5]
                        ));
                    }
                }
            }
            catch (IOException exe)
            {
                MessageBox.Show("Error al leer el archivo: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Archivo dañado o con formato incorrecto: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado al leer: " + exe.Message);
            }
        }
    }
}