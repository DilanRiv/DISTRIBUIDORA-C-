﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class FrmBuscarTienda : Form
    {
        public DatTienda dattie;
        public int idseleccionado = -1;

        public FrmBuscarTienda()
        {
            InitializeComponent();
            try
            {
                dattie = new DatTienda();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar datos: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        public void mostrar(string filtro)
        {
            try
            {
                dataGridView1.Rows.Clear();
                foreach (Tienda aux in dattie.tiendas)
                {
                    if (aux.nombre.ToUpper().Contains(filtro.ToUpper()) || filtro == "")
                    {
                        int rowIndex = dataGridView1.Rows.Add();
                        dataGridView1.Rows[rowIndex].Cells[0].Value = aux.id;
                        dataGridView1.Rows[rowIndex].Cells[1].Value = aux.nombre;
                        dataGridView1.Rows[rowIndex].Cells[2].Value = aux.direccion;
                        dataGridView1.Rows[rowIndex].Cells[3].Value = aux.NIT;
                    }
                }
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Error al cargar tiendas: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            mostrar(textBox1.Text);
        }

        private void FrmBuscarTienda_Load(object sender, EventArgs e)
        {
            try
            {
                mostrar("");
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error al cargar el formulario: " + exe.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}
