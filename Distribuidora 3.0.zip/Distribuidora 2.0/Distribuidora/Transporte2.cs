﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class Transporte2 : Form
    {
        DatTransporte dattransporte = new DatTransporte();
        public DatTransporte dattrans;
        public Transporte2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmNuevoTransporte ftr = new FrmNuevoTransporte();
            ftr.dtra = dattransporte;
            ftr.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmBuscarTransporte fbtra = new FrmBuscarTransporte();
            fbtra.dattran = dattransporte;
            fbtra.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
