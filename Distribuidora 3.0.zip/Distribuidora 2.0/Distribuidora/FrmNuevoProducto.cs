﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distribuidora
{
    public partial class FrmNuevoProducto : Form
    {
        public DatProducto dpro;

        public FrmNuevoProducto()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text) ||
                    string.IsNullOrEmpty(textBox2.Text) ||
                    string.IsNullOrEmpty(textBox3.Text))
                    throw new NullReferenceException("Todos los campos son obligatorios.");

                string nom = textBox1.Text;
                int pre = int.Parse(textBox2.Text);
                int st = int.Parse(textBox3.Text);
                DateTime ven = dateTimePicker1.Value;

                dpro.agregar(new Producto(-1, nom, pre, st, ven));
                Close();
            }
            catch (NullReferenceException exe)
            {
                MessageBox.Show("Campo vacío: " + exe.Message);
            }
            catch (FormatException exe)
            {
                MessageBox.Show("Precio y Stock deben ser números: " + exe.Message);
            }
            catch (Exception exe)
            {
                MessageBox.Show("Error inesperado: " + exe.Message);
            }
        }

   private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

  private void textBox3_TextChanged(object sender, EventArgs e)
       {
        }
  private void label3_Click(object sender, EventArgs e)
        {
        }
  private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }
    private void label2_Click(object sender, EventArgs e)
        {
        }
    private void label4_Click(object sender, EventArgs e)
        {
        }
   private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
        }
    private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    private void label1_Click(object sender, EventArgs e)
        {
        }
    }
}
    

