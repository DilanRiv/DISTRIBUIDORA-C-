﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Distribuidora
{
   public class Transporte
    {
        public int id;
        public string Tipo;
        public string Estado;
        public string Placa;



        public Transporte(int i, string tip, string est, string pla)
        {
            id = i;
            Tipo = tip;
            Estado = est;
            Placa = pla;

            
            

        }
    }
}
